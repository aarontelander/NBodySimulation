#ifndef __VEC3D_HH__
#define __VEC3D_HH__

#include <iostream>
using namespace std;

class Vec3d {

  double x;
  double y;
  double z;

public:

  Vec3d();
  Vec3d(double, double, double);

  double get_x();
  void set_x(double);

  double get_y();
  void set_y(double);

  double get_z();
  void set_z(double);


  Vec3d & operator + (Vec3d &);
  Vec3d & operator - (Vec3d &);
  Vec3d & operator * (double);
  Vec3d & operator / (double);

  void operator += (Vec3d &);
  void operator -= (Vec3d &);
  void operator *= (double);
  void operator /= (double);

  void display() { cout << this->x << " " << this->y << " " << this->z << endl; }

  double distance(double x, double y, double z);
  double distance(Vec3d * other);

  double magnitude();

};

#endif /* def __VEC3D_HH__ */
