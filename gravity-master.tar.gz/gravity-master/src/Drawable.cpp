#include <GL/gl.h>

#include "Drawable.hh"

void Drawable::colorize() {
  glColor3d(this->color->get_r_d(), this->color->get_g_d(), this->color->get_b_d());
}

Drawable::Drawable() {
  this->color = new Color(127, 127, 127);
}

Color * Drawable::get_color() {
  return this->color;
}

void Drawable::set_color(Color color) {
  this->color = new Color(color);
}

void Drawable::set_color(Color *color) {
  this->color = new Color(*color);
}
