#include <GL/glut.h>

#include "Window.hh"
#include "Screen.hh"

Window::Window(string name) {
  this->name = name;

  double screen_size[2];

  screen_size[0] = Screen().getWidth();
  screen_size[1] = Screen().getHeight();

  this->size[0] = (1.0d / 2.0d) * screen_size[0];
  this->size[1] = (1.0d / 2.0d) * screen_size[1];
  this->position[0] = (1.0d / 4.0d) * (screen_size[0]);
  this->position[1] = (1.0d / 4.0d) * (screen_size[1]);
}

Window::Window(string name, double size_x, double size_y, double position_x, double position_y) {
  this->name = name;

  this->size[0] = size_x;
  this->size[1] = size_y;
  this->position[0] = position_x;
  this->position[1] = position_y;
}

void Window::init() {
  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
  glutInitWindowSize(this->size[0], this->size[1]);
  glutInitWindowPosition(this->position[0], this->position[1]);
  this->id = glutCreateWindow(this->name.c_str());
}


GLint * Window::get_id() { return &this->id; }
string * Window::get_name() { return &this->name; }

double * Window::get_size() { return this->size; }
double * Window::get_position() { return this->position; }

void Window::capture_mouse() {
  GLint old_id = glutGetWindow();

  glutSetWindow(*(this->get_id()));

  glutWarpPointer(this->size[0] / 2.0d, this->size[1] / 2.0d);
  glutSetCursor(GLUT_CURSOR_NONE);

  glutSetWindow(old_id);
}
