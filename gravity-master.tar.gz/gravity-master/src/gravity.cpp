#include <iostream>
#include <fstream>
using namespace std;

#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>

#ifdef MACOSX
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "json.hh"

#include "Color.hh"
#include "Body.hh"
#include "Window.hh"
#include "Camera.hh"

#include "BodySystem.hh"
#include "DynamicBodySystemController.hh"
#include "FixedBodySystemController.hh"

char programName[] = "gravity";

Window * main_window = NULL;

clock_t last_frame;

BodySystem * body_system = NULL;

double time_step = 8640000.0d;
bool is_paused = false;

//Body Colors
// Color SUNCLR(250,50,0);
// Color EARTHCLR(0,50,250);
// Color MOONCLR(255,255,255);
// Color MARSCLR(200,60,0);
// Color MRCCLR(200,200,0);
// Color VENCLR(100,200,0);
// Color JUPCLR(200,100,0);
// Color STRNCLR(100,255,10);


// Position Center(WIDTH/2,HEIGHT/2);
// Position temp(120,120);
// Velocity stationary;

// Bodies
//Body(float m, float r, float orbr, Velocity ovel, Position pos, Position cent, float rvel, Color col);

// Body Sun(10, 50, WIDTH/4+100, stationary, temp,Center, 0,SUNCLR, 0.5);
// Body Earth(10,25,0,stationary,Center, Center, 0, EARTHCLR, 1.0);
// Body Moon(10,6, 50,stationary, temp, Center, 0, MOONCLR, 1.0);
// Body Mercury(10,8,70,stationary, temp, Center, 0, MRCCLR, 2);
// Body Venus(10,9,90,stationary, temp, Center, 0, VENCLR, 1.5);
// Body Mars(10,10,140,stationary, temp, Center, 0, MARSCLR, 1.75);
// Body Jupiter(10,28,200,stationary, temp, Center, 0, JUPCLR, 1.10);
// Body Saturn(10,25,250,stationary, temp, Center, 0, STRNCLR, 1.00);

Camera *c = new Camera();

float theta = 0;

void recalculate() {
  double dt = (clock() - last_frame) / (double) CLOCKS_PER_SEC;

  // cout << "updating system with dt " << dt << endl;

  last_frame = clock();

  if(body_system) {
    body_system->update(dt * time_step);
  } else {
    cerr << "Error: body_system is NULL!" << endl;
  }

  c->set_center(&(*body_system->barycenter() * 6.685E-12));
}

void draw()
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glLoadIdentity();

  Vec3d * center = c->get_center();
  Vec3d * position = c->get_position();

  gluLookAt(position->get_x(), position->get_y(), position->get_z(),
            center->get_x(), center->get_y(), center->get_z(),
            0.0, 1.0, 0.0);

  if(body_system) {
    body_system->draw();
  } else {
    cerr << "Error: body_system is NULL!" << endl;
  }

  glPushMatrix(); {
    Vec3d * barycenter = body_system->barycenter();
    glTranslated(barycenter->get_x(), barycenter->get_y(), barycenter->get_z());

    glColor3d((double)rand() / (double)RAND_MAX, (double)rand() / (double)RAND_MAX, (double)rand() / (double)RAND_MAX);

    gluSphere(gluNewQuadric(), 10.0d, 10, 10);
  } glPopMatrix();

  glPushMatrix(); {
    glTranslated(0.0d, 0.0d, 0.0d);
    glBegin(GL_LINES); {
      glLineWidth(1.0d);
      glColor3d(1.0d, 0.0d, 0.0d);

      glVertex3d(-1000.0d, 0.0d, 0.0d);
      glVertex3d(+1000.0d, 0.0d, 0.0d);
    } glEnd();

    glBegin(GL_LINES); {
      glColor3d(0.0d, 1.0d, 0.0d);

      glVertex3d(0.0d, 0.0d, -1000.0d);
      glVertex3d(0.0d, 0.0d, +1000.0d);
    } glEnd();

    glBegin(GL_LINES); {
      glColor3d(0.0d, 0.0d, 1.0d);

      glVertex3d(0.0d, -1000.0d, 0.0d);
      glVertex3d(0.0d, +1000.0d, 0.0d);
    } glEnd();
  } glPopMatrix();

  glutSwapBuffers();

  if(!is_paused)
    recalculate();
  else
    last_frame = clock();

  glutPostRedisplay();
}

void idle() { glutPostRedisplay(); }

void reshape(int w, int h)
{
  double * size = main_window->get_size();

  size[0] = w;
  size[1] = h;

  if(size[1] == 0)
    size[1] = 1;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  glViewport(0, 0, size[0], size[1]);
  gluPerspective(100.0f, size[0] / size[1], 0.01f, 100000.0f);

  glMatrixMode(GL_MODELVIEW);
}

// This function is called when a mouse event is encountered.
void mouse(int button, int state, int x, int y)
{
  switch(button) {
  case 0:
    switch(state) {
    case 0:
      glutSetCursor(GLUT_CURSOR_NONE);
      break;
    case 1:
      glutSetCursor(GLUT_CURSOR_INHERIT);
      break;
    }
    break;
  case 3:
    if(state == 1) { c->set_r(c->get_r() - 0.1d); }
    break;
  case 4:
    if(state == 1) { c->set_r(c->get_r() + 0.1d); }
    break;
  }

  glutPostRedisplay();
}

// This function is called when the mouse is moved with the mouse button held down.
void mouse_motion(int x, int y)
{
  double * size = main_window->get_size();
  double dx = ((double)size[0] / (double)2 - (double)x);
  double dy = ((double)size[1] / (double)2 - (double)y);

  if(abs(dx) > 0 || abs(dy) > 0) {
    c->set_alpha(c->get_alpha() - dy * 0.1);
    c->set_beta(c->get_beta() - dx * 0.1);

    glutWarpPointer(size[0] / 2, size[1] / 2);

    // recalculate();
    glutPostRedisplay();
  }
}

// This function is called when the mouse is moved.
void passive_mouse_motion(int x, int y)
{
}

void keyboard(unsigned char key, int xx, int yy)
{
  switch(key) {
  case 'e':
    c->set_alpha(c->get_alpha() + 1.0d);
    break;
  case 'd':
    c->set_alpha(c->get_alpha() - 1.0d);
    break;
  case 's':
    c->set_beta(c->get_beta() + 1.0d);
    break;
  case 'f':
    c->set_beta(c->get_beta() - 1.0d);
    break;
  case 'w':
    c->set_r(c->get_r() - 0.1d);
    break;
  case 'a':
    c->set_r(c->get_r() + 0.1d);
    break;
  case 'p':
    is_paused = !is_paused;
    glutPostRedisplay();
    break;
  case '.':
    time_step *= 2.0d;
    break;
  case ',':
    time_step /= 2.0d;
    break;
  case 27:
  case 'q':
  case 'Q':
    exit(0);
    break;
  }
}

void key_press(int key, int x, int y)
{
}

void key_release(int key, int x, int y)
{
}

void init(void)
{
  glutDisplayFunc(draw);
  glutReshapeFunc(reshape);
  glutIdleFunc(idle);

  // glutIgnoreKeyRepeat(1);
  glutKeyboardFunc(keyboard);
  glutSpecialFunc(key_press);
  glutSpecialUpFunc(key_release);

  glutMouseFunc(mouse);
  glutMotionFunc(mouse_motion);
  // glutPassiveMotionFunc(passive_mouse_motion);

  glEnable(GL_DEPTH_TEST);

  // welcome message
  cout << "Welcome to " << programName << "." << endl;
}

int main(int argc, char * argv[])
{
  srand((unsigned int)time(NULL));

  glutInit(&argc, argv);

  main_window = new Window("gravity");

  if(argc > 1)
    body_system = new BodySystem(argv[1]);
  else
    body_system = new BodySystem();

  main_window->init();
  init();

  last_frame = clock();

  glutMainLoop();
}
