#include <iostream>
#include <fstream>
#include <string>
using namespace std;

#include <GL/gl.h>

#include "json.hh"

using JSON = nlohmann::json;

#include "BodySystem.hh"

#include "BodySystemController.hh"
#include "DynamicBodySystemController.hh"
#include "FixedBodySystemController.hh"

BodySystem::BodySystem() {

  this->controller = new DynamicBodySystemController();
  this->bodies = new vector<Body *>();

  const unsigned int NUM_RANDOM_BODIES = 128;

  for(unsigned int i = 0; i < NUM_RANDOM_BODIES; i ++) {

    double mass = ((double)rand() / (double)RAND_MAX) * 1.0e28d;
    double radius = mass / 1.0e18d;

    double x = (double)rand() / (double)RAND_MAX * 1.0e12d;
    double y = (double)rand() / (double)RAND_MAX * 1.0e12d;
    double z = (double)rand() / (double)RAND_MAX * 1.0e12d;
    double dx = (((double)rand() / (double)RAND_MAX) - 0.5) * 10000.0d;
    double dy = (((double)rand() / (double)RAND_MAX) - 0.5) * 10000.0d;
    double dz = (((double)rand() / (double)RAND_MAX) - 0.5) * 10000.0d;

    Vec3d * location = new Vec3d(x, y, z);
    Vec3d * velocity = new Vec3d(dx, dy, dz);
    Body * body = new Body(mass, radius, location, velocity);

    this->bodies->push_back(body);
  }

  // Body * b = new Body(0.0d, 0.1d, new Vec3d({0.0d, 0.0d, 0.0d}), new Vec3d({0.0d, 0.0d, 0.0d}));
  // b->get_color().set_r(255);
  // b->get_color().set_g(0);
  // b->get_color().set_b(0);
  // this->bodies->push_back(*b);

}

BodySystem::BodySystem(char * filename) {

  ifstream i(filename);

  JSON file;
  i >> file;

  string controller = file["controller"];

  switch(controller.compare("fixed")) {
  case 0:
    this->controller = new FixedBodySystemController();
    break;
  default:
    this->controller = new DynamicBodySystemController();
    break;
  }

  cout << file["name"] << ", a " << controller << "-controlled system..." << endl;

  this->bodies = new vector<Body *>();

  JSON bodies = file["bodies"];

  for(JSON::iterator it = bodies.begin(); it != bodies.end(); ++ it) {
    JSON e = *it;
    string name = e["name"];

    double mass = e["mass"];
    double radius = e["radius"];

    Color * color = new Color(e["color"][0], e["color"][1], e["color"][2]);

    Vec3d * location = new Vec3d(e["location"][0], e["location"][1], e["location"][2]);
    Vec3d * velocity = new Vec3d(e["velocity"][0], e["velocity"][1], e["velocity"][2]);

    Body *b = new Body(mass, radius, location, velocity);

    b->set_color(color);
    b->name = name;

    b->set_parent(NULL);

    for(unsigned int i = 0; i < this->bodies->size(); i ++) {
      Body *j = this->bodies->at(i);

      string parent = e["parent"];

      if(parent.compare(j->name) == 0) {
        b->set_parent(j);
        break;
      }
    }

    this->bodies->push_back(b);
  }

}

BodySystem::BodySystem(BodySystemController * controller) {

  this->controller = controller;
  this->bodies = new vector<Body *>();

}

BodySystem::BodySystem(BodySystemController * controller, vector<Body *> * bodies) {

  this->controller = controller;
  this->bodies = bodies;

}

Vec3d * BodySystem::barycenter() {

  Vec3d * barycenter = new Vec3d({0.0, 0.0, 0.0});
  double masses = 0.0;

  for(unsigned long i = 0; i < this->bodies->size(); i ++) {
    Body * body = this->bodies->at(i);

    Vec3d * location = body->get_location();
    double mass = body->get_mass();

    *barycenter += *location * mass;
    masses += mass;
  }

  if(masses > 0.0d)
    return &(*barycenter / masses);
  else
    return new Vec3d(0.0d, 0.0d, 0.0d);

}

void BodySystem::draw() {
  for(unsigned long i = 0; i < this->bodies->size(); ++ i) {
    this->bodies->at(i)->draw();
  }
}

void BodySystem::update(double dt) {
  this->controller->update(dt, *bodies);
}
