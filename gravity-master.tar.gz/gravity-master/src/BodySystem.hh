#ifndef __BODY_SYSTEM_HH__
#define __BODY_SYSTEM_HH__

#include <vector>
using namespace std;

#include "Drawable.hh"
#include "Body.hh"
#include "BodySystemController.hh"

class BodySystem : public Drawable {

  vector<Body *> * bodies; /** @param bodies A vector filled with Body* */
  BodySystemController * controller; /** @param controller Pointer to BodySystemController for this system */

public:

  BodySystem();
  /** Default Constructor */
  BodySystem(char * filename);
  /** Filename Constructor */
  BodySystem(BodySystemController *);
  /** BodySystemController* Constructor */
  BodySystem(BodySystemController *, vector<Body *> *);
  /** BodySystemController* and vector Constructor */

  Vec3d * barycenter();
  /** Keeps track of a barycenter */

  void draw();
  /** Draws the BodySystem */
  void update(double);
  /** Animates the BodySystem */

};

#endif /* def __BODY_SYSTEM_HH__ */
