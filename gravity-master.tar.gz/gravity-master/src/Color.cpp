#include <iostream>
using namespace std;

#include "Color.hh"

Color::Color() : red(0x7f), green(0x7f), blue(0x7f) {}
Color::Color(color_channel_t r, color_channel_t g, color_channel_t b) : red(r), green(g), blue(b) {}

color_channel_t Color::get_r()
{
  return this->red;
}

color_channel_t Color::get_g()
{
  return this->green;
}

color_channel_t Color::get_b()
{
  return this->blue;
}

void Color::set_r(color_channel_t r)
{
  this->red = r;
}

void Color::set_g(color_channel_t g)
{
  this->green = g;
}

void Color::set_b(color_channel_t b)
{
  this->blue = b;
}

double Color::get_r_d()
{
  return (double)(this->red) / (double)COLOR_CHANNEL_MAX;
}

double Color::get_g_d()
{
  return (double)(this->green) / (double)COLOR_CHANNEL_MAX;
}

double Color::get_b_d()
{
  return (double)(this->blue) / (double)COLOR_CHANNEL_MAX;
}
