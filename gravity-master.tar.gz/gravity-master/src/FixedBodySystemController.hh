#ifndef __FIXED_BODY_SYSTEM_CONTROLLER_HH__
#define __FIXED_BODY_SYSTEM_CONTROLLER_HH__

#include <vector>
using namespace std;

#include "BodySystemController.hh"

class FixedBodySystemController : public BodySystemController {
public:
  void update(double, vector<Body *> &);
};

#endif /* def __FIXED_BODY_SYSTEM_CONTROLLER_HH__ */
