#include <math.h>

#include "Vec3d.hh"

Vec3d::Vec3d() : x(0.0d), y(0.0d), z(0.0d) {}
Vec3d::Vec3d(double x, double y, double z) : x(x), y(y), z(z) {}

double Vec3d::get_x() { return this->x; }
void Vec3d::set_x(double x) { this->x = x; }

double Vec3d::get_y() { return this->y; }
void Vec3d::set_y(double y) { this->y = y; }

double Vec3d::get_z() { return this->z; }
void Vec3d::set_z(double z) { this->z = z; }

Vec3d & Vec3d::operator + (Vec3d & other)
{
  return *(new Vec3d(this->x + other.x, this->y + other.y, this->z + other.z));
}

Vec3d & Vec3d::operator - (Vec3d & other)
{
  return *(new Vec3d(this->x - other.x, this->y - other.y, this->z - other.z));
}

Vec3d & Vec3d::operator * (double scalar)
{
  return *(new Vec3d(this->x * scalar, this->y * scalar, this->z * scalar));
}

Vec3d & Vec3d::operator / (double scalar)
{
  return *(new Vec3d(this->x / scalar, this->y / scalar, this->z / scalar));
}

void Vec3d::operator += (Vec3d & other)
{
  this->x += other.x;
  this->y += other.y;
  this->z += other.z;
}

void Vec3d::operator -= (Vec3d & other)
{
  this->x -= other.x;
  this->y -= other.y;
  this->z -= other.z;
}

void Vec3d::operator *= (double scalar)
{
  this->x *= scalar;
  this->y *= scalar;
  this->z *= scalar;
}

void Vec3d::operator /= (double scalar)
{
  this->x /= scalar;
  this->y /= scalar;
  this->z /= scalar;
}

double Vec3d::distance(double x, double y, double z) {

  return sqrt(pow(x - this->x, 2.0d) +
              pow(y - this->y, 2.0d) +
              pow(z - this->z, 2.0d));

}

double Vec3d::distance(Vec3d * other) {

  return distance(other->x, other->y, other->z);

}


double Vec3d::magnitude() {
  return sqrt(pow(this->x, 2.0d) + pow(this->y, 2.0d) + pow(this->z, 2.0d));
}
