#include <stdlib.h>

#include "Random.hh"

double rando() {
  return (double) rand() / (double) RAND_MAX;
}
