#ifndef __SCREEN_HH__
#define __SCREEN_HH__

class Screen {
public:
  static int getWidth();
  static int getHeight();
};

#endif /* def __SCREEN_HH__ */
