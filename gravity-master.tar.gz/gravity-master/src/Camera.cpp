#include <math.h>

#include "Camera.hh"


Camera::Camera()
{
  this->center = new Vec3d(0.0d, 0.0d, 0.0d);

  r = 10.0d;
  alpha = 45.0d;
  beta = 45.0d;
}

Vec3d * Camera::get_center()
{
  return this->center;
}

void Camera::set_center(Vec3d * center)
{
  this->center = new Vec3d(*center);
}

void Camera::set_center(Vec3d center)
{
  this->center = new Vec3d(center);
}

double Camera::get_r()
{
  return this->r;
}

void Camera::set_r(double r)
{
  if(r > 0.1d)
    this->r = r;
  else
    this->r = 0.1d;
}

double Camera::get_alpha()
{
  return this->alpha;
}

void Camera::set_alpha(double alpha) {
  this->alpha = alpha;

  if(this->alpha >= 89.9999d) this->alpha = 89.9999d;
  if(this->alpha <= -89.9999d) this->alpha = -89.9999d;
}

double Camera::get_beta()
{
  return this->beta;
}

void Camera::set_beta(double beta) {
  this->beta = beta;

  if(this->beta <= 0.0d) this->beta += 360.0d;
  if(this->beta > 360.0d) this->beta -= 360.0d;
}

Vec3d * Camera::get_position() {
  return new Vec3d(this->center->get_x() + this->r * cos(alpha * M_PI / 180.0d) * cos(beta * M_PI / 180.0d),
                   this->center->get_y() + this->r * sin(alpha * M_PI / 180.0d),
                   this->center->get_z() + this->r * cos(alpha * M_PI / 180.0d) * sin(beta * M_PI / 180.0d));
}
