#ifndef __RANDOM_HH__
#define __RANDOM_HH__

double rando();

#endif /* def __RANDOM_HH__ */
