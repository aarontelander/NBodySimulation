#include <GL/glut.h>

#include "Screen.hh"

int Screen::getWidth() {
  return glutGet(GLUT_SCREEN_WIDTH);
}

int Screen::getHeight() {
  return glutGet(GLUT_SCREEN_HEIGHT);
}
