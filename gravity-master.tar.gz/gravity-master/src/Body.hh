#ifndef __BODY_H__
#define __BODY_H__

#include <string>
#include <vector>
using namespace std;

#include <GL/glu.h>

#include "Drawable.hh"
#include "Vec3d.hh"

class Body : public Drawable {

  double mass;
  double radius;

  Vec3d * velocity;
  Vec3d * location;

  Body * parent;

  GLUquadric *gquad;

  vector<Vec3d *> *trail;

public:

  string name;

  Body();
  Body(double, double, Vec3d *);
  Body(double, double, Vec3d *, Vec3d *);

  double get_mass();
  void set_mass(double);

  double get_radius();
  void set_radius(double);

  Vec3d * get_location();
  void set_location(Vec3d *);
  void set_location(Vec3d);

  Body * get_parent();
  void set_parent(Body *);

  Vec3d * get_velocity();
  void set_velocity(Vec3d *);
  void set_velocity(Vec3d);

  void draw();

  void add_trail_point(Vec3d * point);

};

#endif /* def __BODY_HH__ */
