#ifndef __BODY_SYSTEM_CONTROLLER_HH__
#define __BODY_SYSTEM_CONTROLLER_HH__

#include <vector>
using namespace std;

#include "Body.hh"

class BodySystemController {
public:
  virtual void update(double, vector<Body *> &) = 0;
  /** Virtual function for BodySystem class */
};

#endif /* def __BODY_SYSTEM_CONTROLLER_HH__ */
