#include <iostream>
using namespace std;

#include <math.h>

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#include "Random.hh"

#include "Vec3d.hh"
#include "Body.hh"

Body::Body() : Drawable(), mass(0.0d), radius(0.0d) {

  this->velocity = new Vec3d(0.0d, 0.0d, 0.0d);
  this->location = new Vec3d(0.0d, 0.0d, 0.0d);

  this->gquad = gluNewQuadric();

  this->color = new Color((unsigned char)(rando() * 255.0d), (unsigned char)(rando() * 255.0d), (unsigned char)(rando() * 255.0d));

  this->trail = new vector<Vec3d *>();
}

Body::Body(double mass, double radius, Vec3d * location) : Drawable(), mass(mass), radius(radius) {

  this->location = new Vec3d(*location);
  this->velocity = new Vec3d({0.0d, 0.0d, 0.0d});

  this->gquad = gluNewQuadric();

  this->color = new Color((unsigned char)(rando() * 255.0d), (unsigned char)(rando() * 255.0d), (unsigned char)(rando() * 255.0d));

  this->trail = new vector<Vec3d *>();

}

Body::Body(double mass, double radius, Vec3d * location, Vec3d * velocity) : Drawable(), mass(mass), radius(radius) {

  this->location = new Vec3d(*location);
  this->velocity = new Vec3d(*velocity);

  this->gquad = gluNewQuadric();

  this->color = new Color((unsigned char)(rando() * 255.0d), (unsigned char)(rando() * 255.0d), (unsigned char)(rando() * 255.0d));

  this->trail = new vector<Vec3d *>();

}

double Body::get_mass() { return this->mass; }
void Body::set_mass(double mass) { this->mass = mass; }

double Body::get_radius() { return this->radius; }
void Body::set_radius(double radius) { this->radius = radius; }

Vec3d * Body::get_location() { return this->location; }
void Body::set_location(Vec3d * location) { this->location = new Vec3d(*location); }
void Body::set_location(Vec3d location) { this->location = new Vec3d(location); }

Body * Body::get_parent() { return this->parent; }
void Body::set_parent(Body * parent) { this->parent = parent; }

Vec3d * Body::get_velocity() { return this->velocity; }
void Body::set_velocity(Vec3d * velocity) { this->velocity = new Vec3d(*velocity); }
void Body::set_velocity(Vec3d velocity) { this->velocity = new Vec3d(velocity); }

const unsigned long NUM_SLICES = 36;

void Body::draw() {
  glPushMatrix(); {
    glTranslated(this->location->get_x() * 6.685E-12, this->location->get_y() * 6.685E-12, this->location->get_z() * 6.685E-12);

    this->colorize();

    double rad = 4E-3d * log(2.210E2d * this->radius);

    gluSphere(this->gquad, this->radius * 6.685E-12, NUM_SLICES, NUM_SLICES);

  } glPopMatrix();

  glBegin(GL_LINE_STRIP); {

    for(unsigned long i = 0; i < this->trail->size(); i ++) {
      Vec3d * point = this->trail->at(i);

      glVertex3d(point->get_x() * 6.685E-12, point->get_y() * 6.685E-12, point->get_z() * 6.685E-12);
    }

  } glEnd();
}

void Body::add_trail_point(Vec3d *point) {
  this->trail->push_back(point);

  if(this->trail->size() > 5000)
    this->trail->erase(this->trail->begin());
}
