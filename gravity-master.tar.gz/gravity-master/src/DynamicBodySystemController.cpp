#include <math.h>

#include "DynamicBodySystemController.hh"

const double G = 6.67408E-11;

void DynamicBodySystemController::update(double dt, vector<Body *> & bodies) {
  for(unsigned long i = 0; i < bodies.size(); i ++) {
    Body * body = bodies.at(i);

    Vec3d * net_force = new Vec3d({0.0, 0.0, 0.0});

    Vec3d * velocity = body->get_velocity();
    Vec3d * location = body->get_location();

    for(unsigned int j = 0; j < bodies.size(); j ++) {
      Body * other = bodies.at(j);

      Vec3d * other_location = other->get_location();
      Vec3d * distance = &(*other_location - *location);

      double distance_mag = distance->magnitude();
      double force_magnitude = 0.0d;

      if(distance_mag >= 0.0000001) {
        force_magnitude = ((G * body->get_mass() * other->get_mass()) / pow(distance_mag, 2.0));

        // cout << body->name << " to " << other->name << " -- net_force: ";
        // ((*distance / distance_mag) * force_magnitude).display();

        *net_force += (*distance / distance_mag) * force_magnitude;
      } else {
        force_magnitude = 0.0d;
      }
    }

    body->add_trail_point(new Vec3d(*location));

    Vec3d * dv = NULL;

    if(body->get_mass() > 0.0d)
      dv = new Vec3d(*net_force * (dt / body->get_mass()));
    else
      dv = new Vec3d(0.0d, 0.0d, 0.0d);

    Vec3d * dl = new Vec3d((*velocity + *dv) * dt);

    body->set_location(*location + *dl);
    body->set_velocity(*velocity + *dv);

    // cout << "body " << i << endl;
    // location->display();
    // velocity->display();
    // cout << "   " << endl;
  }
}
