#ifndef __CAMERA_HH__
#define __CAMERA_HH__

#include "Vec3d.hh"

class Camera {

  Vec3d * center; /** @param center Center of the System */

  double r; /** @param r Distance from the center */
  double alpha; /** @param alpha Vertical Angle of the Camera */
  double beta; /** @param beta Horizontal Angle of the Camera */

public:

  Camera();

  Vec3d * get_center(); 
  /** Obtain center state variable
  @return The center of the System */
  void set_center(Vec3d *);
  /** Set center state variable Pointer Version
  @param center Pointer to the New center for the system
  @return The New center of the System */
  void set_center(Vec3d);
  /** Set center state variable Non-Pointer Version
  @param center New center for the system
  @return The New center of the System */

  double get_r();
  /** Obtain r state variable
  @return The Distance from the center */
  void set_r(double);
  /** Set r state variable
  @param r New r */

  double get_alpha();
  /** Obtain alpha state variable
  @return Vertical Angle of the Camera */
  void set_alpha(double);
  /** Set alpha state variable
  @param alpha New alpha */

  double get_beta();
  /** Obtain beta state variable
  @return Horizontal Angle of the Camera */
  void set_beta(double);
  /** Set beta state variable
  @param beta New beta */

  Vec3d * get_position();
  /** Calculate hypotenuse vector of alpha and beta
  @return 3-D vector between alpha and beta */

};


#endif /* def __CAMERA_HH__ */
