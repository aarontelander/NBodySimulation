#ifndef __DRAWABLE_H__
#define __DRAWABLE_H__

#include "Color.hh"

class Drawable {

protected:

  Color * color; /** @param color Color of a Body */

  void colorize();
  /** Obtains all colors for OpenGL */

public:

  Drawable();
  /** Default Constructor - Sets color values to 127 */

  Color * get_color();
  /** Obtains color state variable
  @return a Color pointer to the object's color state variable */

  void set_color(Color);
  /** Set color state variable Non-Pointer Version 
  @param color a new color for the object */
  void set_color(Color *);
  /** Set color state variable Pointer Version
  @param color a pointer to a new color for the object */

  virtual void draw() = 0;
  /** Virtual function for drawing */

};

#endif /* def __DRAWABLE_H__ */
