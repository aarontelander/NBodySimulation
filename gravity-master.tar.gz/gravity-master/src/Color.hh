#ifndef __COLOR_H__
#define __COLOR_H__

typedef unsigned char color_channel_t;
const color_channel_t COLOR_CHANNEL_MAX = 255;

class Color {

  color_channel_t red;
  color_channel_t green;
  color_channel_t blue;

public:

  Color();
  Color(color_channel_t, color_channel_t, color_channel_t);

  color_channel_t get_r();
  color_channel_t get_g();
  color_channel_t get_b();

  void set_r(color_channel_t);
  void set_g(color_channel_t);
  void set_b(color_channel_t);

  double get_r_d();
  double get_g_d();
  double get_b_d();

};

#endif /* def __COLOR_H__ */
