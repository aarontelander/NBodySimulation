#include "FixedBodySystemController.hh"

void update_body(double dt, Body * body, Body * parent)
{
  Vec3d * center = NULL;
  Vec3d * pvel = NULL;

  if(parent != NULL) {
    center = parent->get_location();
    pvel = parent->get_velocity();
  } else {
    center = new Vec3d(0.0d, 0.0d, 0.0d);
    pvel = new Vec3d(0.0d, 0.0d, 0.0d);
  }

  Vec3d * p1 = body->get_location();
  Vec3d * v1 = new Vec3d(*pvel + *body->get_velocity());

  Vec3d * r1 = new Vec3d(*p1 - *center);

  Vec3d * r2 = new Vec3d(*r1 + *v1 * dt);
  Vec3d * r2hat = new Vec3d(*r2 / r2->magnitude());

  double v1mag = v1->magnitude();

  Vec3d * p2 = new Vec3d(*r2hat * r1->magnitude());

  Vec3d * v20 = new Vec3d(1.0d, 0.0d, -(r2hat->get_x() / r2hat->get_z()));
  *v20 *= (v1mag / v20->magnitude());
  Vec3d * v21 = new Vec3d(-1.0d, 0.0d, (r2hat->get_x() / r2hat->get_z()));
  *v21 *= (v1mag / v21->magnitude());

  double d0 = v20->distance(v1);
  double d1 = v21->distance(v1);

  if(v1mag > 0.0d) {
    if(d0 > d1) {
      body->set_velocity(v21);
    } else {
      body->set_velocity(v20);
    }
    body->add_trail_point(p1);

    body->set_location(*center + *p2);
  } else {
  }

}

void FixedBodySystemController::update(double dt, vector<Body *> & bodies) {

  for(unsigned int i = 0; i < bodies.size(); i ++) {
    Body * body = bodies.at(i);

    // vector<Body *> children;

    // for(unsigned int j = 0; j < bodies.size(); j ++) {
    //   if(bodies.at(j)->get_parent() == body)
    //     children.push_back(bodies.at(j));
    // }

    // update_children(dt, body, children);

    if(body->get_parent()) {
      update_body(dt, body, body->get_parent());
    } else {
      update_body(dt, body, NULL);
    }

  }

}
