#ifndef __DYNAMIC_BODY_SYSTEM_CONTROLLER_HH__
#define __DYNAMIC_BODY_SYSTEM_CONTROLLER_HH__

#include <vector>
using namespace std;

#include "BodySystemController.hh"

class DynamicBodySystemController : public BodySystemController {
public:
  void update(double, vector<Body *> &);
};

#endif /* def __DYNAMIC_BODY_SYSTEM_CONTROLLER_HH__ */
