#ifndef __WINDOW_HH__
#define __WINDOW_HH__

#include <string>
using namespace std;

#include <GL/gl.h>

class Window {

  GLint id;
  string name;

  double size[2];
  double position[2];

public:

  Window(string);
  Window(string, double, double, double, double);

  void init();

  GLint * get_id();
  string * get_name();

  double * get_size();
  double * get_position();

  void capture_mouse();

};

#endif /* def __WINDOW_HH__ */
